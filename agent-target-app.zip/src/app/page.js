
import { useEffect, useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Card, CardContent } from '@/components/ui/card';

const fanfareUrl = 'https://cdn.pixabay.com/audio/2022/03/15/audio_145e2ccbaa.mp3';

export default function AgentApp() {
  const [agents, setAgents] = useState([]);
  const [showAnimation, setShowAnimation] = useState(false);
  const [currentAgent, setCurrentAgent] = useState(null);

  const [form, setForm] = useState({ name: '', target: '', amount: '' });

  useEffect(() => {
    const stored = localStorage.getItem('agents');
    if (stored) {
      setAgents(JSON.parse(stored));
    }
  }, []);

  const playSound = () => {
    const audio = new Audio(fanfareUrl);
    audio.play();
  };

  const handleAdd = () => {
    const { name, target, amount } = form;
    if (!name || !target || !amount) return;

    const targetNum = parseFloat(target);
    const amountNum = parseFloat(amount);

    const newAgent = {
      name,
      target: targetNum,
      amount: amountNum,
      percent: Math.min(100, Math.round((amountNum / targetNum) * 100)),
    };

    const updatedAgents = [...agents, newAgent];
    setAgents(updatedAgents);
    localStorage.setItem('agents', JSON.stringify(updatedAgents));

    setCurrentAgent(newAgent);
    setShowAnimation(true);
    playSound();

    setTimeout(() => setShowAnimation(false), 5000);
    setForm({ name: '', target: '', amount: '' });
  };

  return (
    <div className="min-h-screen bg-black text-gold p-6 font-sans">
      <h1 className="text-3xl font-bold text-center mb-6 text-gold">💼 Агентский Таргет</h1>

      <div className="bg-zinc-900 p-4 rounded-2xl max-w-xl mx-auto shadow-lg">
        <h2 className="text-xl mb-2">Администратор</h2>
        <input
          type="text"
          placeholder="Имя агента"
          value={form.name}
          onChange={(e) => setForm({ ...form, name: e.target.value })}
          className="w-full mb-2 p-2 rounded bg-zinc-800 text-white"
        />
        <input
          type="number"
          placeholder="Таргет"
          value={form.target}
          onChange={(e) => setForm({ ...form, target: e.target.value })}
          className="w-full mb-2 p-2 rounded bg-zinc-800 text-white"
        />
        <input
          type="number"
          placeholder="Сумма пополнения"
          value={form.amount}
          onChange={(e) => setForm({ ...form, amount: e.target.value })}
          className="w-full mb-2 p-2 rounded bg-zinc-800 text-white"
        />
        <button
          onClick={handleAdd}
          className="w-full py-2 bg-yellow-500 text-black rounded font-bold hover:bg-yellow-400"
        >
          Завести сумму
        </button>
      </div>

      <div className="mt-10 max-w-3xl mx-auto">
        <h2 className="text-xl mb-4">📋 История пополнений</h2>
        <div className="overflow-x-auto">
          <table className="min-w-full bg-zinc-900 rounded-xl text-left">
            <thead>
              <tr className="text-gold border-b border-yellow-600">
                <th className="p-2">Имя</th>
                <th className="p-2">Таргет</th>
                <th className="p-2">Сумма</th>
                <th className="p-2">% Выполнено</th>
              </tr>
            </thead>
            <tbody>
              {agents.map((a, i) => (
                <tr key={i} className="text-white border-t border-zinc-700">
                  <td className="p-2">{a.name}</td>
                  <td className="p-2">{a.target} ₽</td>
                  <td className="p-2">{a.amount} ₽</td>
                  <td className="p-2">{a.percent}%</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      <AnimatePresence>
        {showAnimation && currentAgent && (
          <motion.div
            initial={{ opacity: 0, scale: 0.8 }}
            animate={{ opacity: 1, scale: 1 }}
            exit={{ opacity: 0, scale: 0.8 }}
            className="fixed inset-0 flex items-center justify-center bg-black/80 z-50"
          >
            <div className="text-center text-yellow-400">
              <h2 className="text-4xl font-extrabold mb-2 animate-pulse">🎉 {currentAgent.name}</h2>
              <p className="text-3xl">завёл {currentAgent.amount} ₽!</p>
              <p className="text-xl mt-2">🔥 Выполнено: {currentAgent.percent}% от таргета</p>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
